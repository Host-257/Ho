=================================================================
README

O&O DISKRECOVERY

RELEASE 8.0 BUILD 335

=================================================================

CONTENTS:
---------

1) INSTALLATION NOTES
2) SUPPORT / CONTACT

-----------------------------------------------------------------
1) INSTALLATION NOTES
---------------------

* O&O DiskRecovery works with the following operating systems:

  + Windows 2000 Professional
  + Windows 2000 Server
  + Windows 2000 Advanced Server
  + Windows XP Home Edition
  + Windows XP Professional Edition x32/64
  + Windows Server 2003 (all editions, x32/x64)
  + Windows Vista (all editions, x32/x64)
  + Windows Server 2008 (all editions, x32/x64)
  + Microsoft Windows 7 (all editions, x32/x64)
  + Microsoft Windows Server 2008 R2 (all editions)
  + Microsoft Windows 8 (all editions, x32/x64)

* You need Microsoft Internet Explorer 6.0 or higher for
  correct functioning of O&O DiskRecovery. In addition, it is
  required for displaying the online help. 

* To uninstall O&O DiskRecovery, you may remove the entry
  "O&O DiskRecovery" using "Add/Remove Software" from the
  control panel.

-----------------------------------------------------------------
2) SUPPORT / CONTACT
--------------------

O&O Software GmbH

Office:     Am Borsigturm 48
            13507 Berlin
            Germany

Phone:      ++49(30) 991 9162-00
Fax:        ++49(30) 991 9162-99

Sales:      sales@oo-software.com
Info:       info@oo-software.com
Support:    support@oo-software.com

Internet:   http://www.oo-software.com
-----------------------------------------------------------------



